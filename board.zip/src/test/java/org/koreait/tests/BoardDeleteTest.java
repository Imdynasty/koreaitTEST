package org.koreait.tests;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.koreait.controllers.BoardForm;
import org.koreait.models.board.BoardSaveService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@Transactional
@AutoConfigureMockMvc
@TestPropertySource(locations = "classpath:application-test.properties")
public class BoardDeleteTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private BoardSaveService saveService;

    private BoardForm boardForm;

    @BeforeEach
    void init() {
        boardForm = BoardForm.builder()
                .subject("제목")
                .content("내용")
                .build();

        saveService.save(boardForm);
    }

    @Test
    @DisplayName("게시글 삭제 성공시 상태코드 204로 응답")
    void test() throws Exception {

        mockMvc.perform(delete("/api/board/" + boardForm.getId()))
                .andExpect(status().isNoContent());
    }

    @Test
    @DisplayName("없는 게시글 삭제 시도할 경우 상태코드 400으로 응답")
    void test2() throws Exception {

        mockMvc.perform(delete("/api/board/" + System.currentTimeMillis()))
                .andExpect(status().isBadRequest());
    }

}
