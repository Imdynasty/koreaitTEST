package org.koreait.tests;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.koreait.controllers.BoardForm;
import org.koreait.entities.BoardData;
import org.koreait.models.board.BoardListService;
import org.koreait.models.board.BoardSaveService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.Charset;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@Transactional
@AutoConfigureMockMvc
@TestPropertySource(locations = "classpath:application-test.properties")
public class BoardListTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private BoardSaveService saveService;

    @Autowired
    private BoardListService listService;

    private BoardForm boardForm;

    @BeforeEach
    void init() {
        for(int i = 1; i <= 10; i++) {
            boardForm = BoardForm.builder()
                    .subject("제목" + i)
                    .content("내용" + i)
                    .build();

            saveService.save(boardForm);
        }
    }

    @Test
    @DisplayName("게시글 목록 조회 성공시 응답 코드 200, 조회된 게시글 목록 갯수 체크")
    void test1() throws Exception {
        String list = mockMvc.perform(get("/api/board/list"))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString(Charset.forName("UTF-8"));

        ObjectMapper om = new ObjectMapper();
        om.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY); // list deserialization 기능 활성화

        List<Object> result = om.readValue(list, new TypeReference<>(){});
        result.stream().forEach(System.out::println);

        assertEquals(listService.gets().size(), boardForm.getId()); // 게시글 갯수 확인
    }

}
