window.addEventListener("DOMContentLoaded", function() {
    CKEDITOR.replace("content", {
        height: 300
    })

});