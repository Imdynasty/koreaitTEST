package org.koreait.restcontrollers.board;

import lombok.RequiredArgsConstructor;
import org.koreait.commons.rests.JSONData;
import org.koreait.controllers.BoardForm;
import org.koreait.entities.BoardData;
import org.koreait.models.board.BoardDeleteService;
import org.koreait.models.board.BoardInfoService;
import org.koreait.models.board.BoardListService;
import org.koreait.models.board.BoardSaveService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController("apiBoardController")
@RequestMapping("/api/board")
@RequiredArgsConstructor
public class BoardController {

    private final BoardSaveService saveService;

    private final BoardInfoService infoService;

    private final BoardListService listService;

    private final BoardDeleteService deleteService;

    @PostMapping
    public ResponseEntity<Object> write(@RequestBody BoardForm boardForm) {

        saveService.save(boardForm);

        // 등록 성공
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }


    @PatchMapping
    public ResponseEntity<Object> edit(@RequestBody BoardForm boardForm) {

        saveService.save(boardForm);

        return ResponseEntity.status(HttpStatus.OK).build();
    }

    @GetMapping("/view/{id}")
    public ResponseEntity<JSONData<Object>> view(@PathVariable Long id) {

        BoardData boardData = infoService.get(id);

        JSONData<Object> data = JSONData.builder()
                .success(true)
                .data(boardData)
                .build();

        return ResponseEntity.ok(data);
    }

    @GetMapping("/list")
    public ResponseEntity<JSONData<Object>> list() {

        List<BoardData> boardData = listService.gets();

        JSONData<Object> data = JSONData.builder()
                .success(true)
                .data(boardData)
                .build();

        return ResponseEntity.ok(data);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Object> delete(@PathVariable Long id) {

        deleteService.delete(id);

        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }


}
